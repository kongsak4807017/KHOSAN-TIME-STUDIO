# Oriverse Capability Audit — SVG Workflow Reconstruction

16 editable SVG workflows + Graphviz DOT sources + HTML index.

**Provenance:** Reconstructed diagrams based on the user-supplied `Oriverse Capability Audit.docx` and the project KHOSAN architecture materials. **Not an exact recovery of every historic chat SVG.** Some flows explicitly mark **Proposed** capabilities.

**Evidence discipline:** documented/observed claims must be distinguished from proposed KHOSAN architecture; diagrams do not prove undocumented Oriverse capabilities.

## Practical integration
1. Store the audit DOCX as reference, not runtime source.
2. Convert findings into machine-readable capability registry with `documented`, `observed`, `inferred`, `undisclosed`, `proposed` flags.
3. Implement adapter interface with read-only discovery and compile/playtest verification first.
4. Introduce revision guards, source snapshots, immutable evidence receipts, human approval before world edits/publishing.
5. Validate a small playable vertical slice before cross-engine portability.

## Status at packaging
Oriverse editor session unavailable (no editor online); SVG files were generated locally, **not** runtime-verified.
